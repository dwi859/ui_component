import React, {Component} from 'react';



const Nama = (props) => {

    return(
<div class="App">
<h1>{props.nama}</h1>
</div>
        
    
  
    )
  
}
export default Nama;

